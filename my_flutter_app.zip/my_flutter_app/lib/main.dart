import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'spotify_provider.dart';
import 'home_page.dart';
import 'weather_service.dart';
import 'spotify_service.dart';
import 'weather_model.dart';
import 'failure_model.dart';
import 'artist_screen.dart';
import 'song_detail_screen.dart';
import 'notion_interaction.dart';
import 'test_ui.dart';
import 'constants/Theme.dart';
import 'screens/pomodoro_timer.dart';
import 'screens/stopwatch.dart';
import 'screens/timer.dart';
import 'screens/alarm.dart';
import 'screens/world_clock.dart';
import 'screens/calculator.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
            create: (_) => SpotifyProvider(
                spotifyService: SpotifyService('https://api.spotify.com'))),
      ],
      child: MaterialApp(
        title: 'Flutter Demo',
        theme: ThemeData(
          primaryColor: NowUIColors.primary,
        ),
        home: HomeScreen(),
        routes: {
          '/artist': (context) => ArtistScreen(),
          '/songDetail': (context) => SongDetailScreen(),
          '/testUI': (context) => TestUI(),
          '/home': (context) => Home(),
        },
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  static List<Widget> _widgetOptions = <Widget>[
    PomodoroTimer(),
    StopwatchScreen(),
    TimerScreen(),
    AlarmScreen(),
    WorldClockScreen(),
    CalculatorScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Utility App'),
      ),
      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.timer),
            label: 'Pomodoro',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.timer),
            label: 'Stopwatch',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.timer),
            label: 'Timer',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.alarm),
            label: 'Alarm',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.watch),
            label: 'World Clock',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calculate),
            label: 'Calculator',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
    );
  }
}
